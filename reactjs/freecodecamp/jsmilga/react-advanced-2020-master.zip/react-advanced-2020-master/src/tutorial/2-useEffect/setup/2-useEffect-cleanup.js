import React, { useState, useEffect } from 'react';

// cleanup function
// second argument

const UseEffectCleanup = () => {
  return <h2>useEffect cleanup</h2>;
};

export default UseEffectCleanup;
