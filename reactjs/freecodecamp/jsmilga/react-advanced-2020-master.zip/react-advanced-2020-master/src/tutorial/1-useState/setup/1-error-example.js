import React from 'react';

const ErrorExample = () => {
  return <h2>useState error example</h2>;
};

export default ErrorExample;
