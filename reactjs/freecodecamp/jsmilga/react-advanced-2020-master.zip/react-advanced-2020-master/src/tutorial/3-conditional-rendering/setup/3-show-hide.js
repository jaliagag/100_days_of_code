import React, { useState, useEffect } from 'react';

const ShowHide = () => {
  return <h2>show/hide</h2>;
};

export default ShowHide;
