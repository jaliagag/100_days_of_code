import React, { useState } from 'react';

const UseStateObject = () => {
  return <h2>useState object example</h2>;
};

export default UseStateObject;
